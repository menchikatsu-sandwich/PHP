<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Camera Rental System</title>
</head>
<body>
    <header>
        <h1>Camera Rental System</h1>
        <nav>
            <a href="<?= BASEURL ?>/User/logout">Logout</a>
        </nav>
    </header>
