<footer>
    <p>&copy; 2024 Camera Rental System</p>
</footer>
</body>
</html>
