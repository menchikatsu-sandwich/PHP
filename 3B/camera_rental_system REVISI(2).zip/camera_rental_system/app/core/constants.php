<?php
define('BASEURL', 'http://localhost/WEB2024/3B/camera_rental_system/public');
define('DB_HOST', 'localhost');
define('DB_NAME', 'camera_rental_system');
define('DB_USER', 'root');
define('DB_PASS', '');
