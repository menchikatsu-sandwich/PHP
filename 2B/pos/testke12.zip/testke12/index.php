<!DOCTYPE html>
<html>
<head>
    <title>TOKO BELANJA BAHAGIA</title>
    <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
    <h1>SELAMAT DATANG DI TOKO BELANJA BAHAGIA</h1><br><br><br><br><br><br>
        <a href="produk.php?customer=umum">Belanja sebagai Umum</a><br>
        <a href="daftar_member.php">Belanja sebagai Member</a>
</body>
</html>