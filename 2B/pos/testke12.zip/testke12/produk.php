<?php
session_start();
include 'koneksi.php';

if (!isset($_GET['customer'])) {
    header('Location: index.php');
}

$customer = $_GET['customer'];

$query = "SELECT * FROM produk";
$result = $koneksi->query($query);

echo "<h1>Daftar Produk</h1>";
echo "<form method='post' action='keranjang.php'>";
while ($row = $result->fetch_assoc()) {
    echo "<div class='produk-item'>";
    echo "<span class='nama-produk'>" . $row['nama_produk'] . " - " . $row['harga_jual'] . "</span>";
    echo "<input type='number' name='qty[" . $row['kode_produk'] . "]' min='0' value='0'>";
    echo "</div>";
}
echo "<input type='hidden' name='customer' value='$customer'>";
echo "<button type='submit'>Tambah ke Keranjang</button>";
echo "</form>";
?>

<link rel="stylesheet" type="text/css" href="css/produk.css">