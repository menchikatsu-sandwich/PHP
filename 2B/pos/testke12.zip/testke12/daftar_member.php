<?php
include 'koneksi.php';

if (isset($_POST['daftar'])) {
    $nama = $_POST['nama'];
    $nik = $_POST['nik'];
    $alamat = $_POST['alamat'];
    $noHP = $_POST['noHP'];

    $query = "INSERT INTO pembeli (id_member, nama_member, nik, alamat, noHP) VALUES (NULL, '$nama', '$nik', '$alamat', '$noHP')";
    $koneksi->query($query);

    header('Location: produk.php?customer=' . $nama);
}
?>
<link rel="stylesheet" type="text/css" href="css/member.css">
<style>
    body {
        background-image: url('css/Screenshot 2024-07-17 120621.png');
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
    }
</style>

<form method="post" action="">
    Nama: <input type="text" name="nama" required><br>
    NIK: <input type="text" name="nik" required><br>
    Alamat: <input type="text" name="alamat" required><br>
    No HP: <input type="text" name="noHP" required><br>
    <button type="submit" name="daftar">Daftar</button>
</form>
